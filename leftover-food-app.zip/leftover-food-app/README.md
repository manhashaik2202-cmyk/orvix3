# PlateShare - Leftover Food Sharing App

Restaurants and homes post surplus food. Nearby volunteers and NGOs claim it and collect it.
The app tracks freshness, pickup times and food saved.

## Run it
1. Install Node.js 16 or newer from https://nodejs.org
2. Open a terminal in this folder
3. Run: `node server.js`  (or `npm start`)
4. Open http://localhost:3000

No `npm install` is needed. There are no dependencies.

## Features
- Donors post food: type, servings, weight, prepared time, safe hours, pickup deadline, address, notes
- Freshness tracking: a live bar and countdown (Fresh, Use soon, Expired)
- Expired or overdue food is locked automatically so nobody claims unsafe food
- Volunteers and NGOs claim food with a pickup time, then mark it collected
- Donors can withdraw listings or confirm handover
- Impact dashboard: meals saved, kg rescued, available, waiting, expired
- Search and filter by food type or area
- Works on phone and desktop, supports dark mode

## Flow
Available -> Claimed -> Collected (or Expired / Cancelled)

## API
- GET  /api/listings
- POST /api/listings
- POST /api/listings/:id/claim
- POST /api/listings/:id/collect
- POST /api/listings/:id/cancel

## Files
- server.js: HTTP server and API
- data/db.json: created on first run with 3 sample listings (delete it to reset)
- public/: index.html, style.css, app.js

## Ideas to extend
Map view with distance, SMS or WhatsApp alerts, login and ratings, a database such as SQLite or MongoDB.
