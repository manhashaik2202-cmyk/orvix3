// Leftover Food Sharing App - zero-dependency Node.js server (Node 16+)
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, 'data', 'db.json');
const PUB = path.join(__dirname, 'public');
const H = 3600 * 1000;

function load() {
  if (!fs.existsSync(DB)) {
    const now = Date.now();
    const seed = [
      { donor: 'Spice Garden Restaurant', title: 'Veg biryani and raita', category: 'Cooked meal', servings: 40, kg: 14, location: 'MG Road, Vijayawada', contact: '98480 11111', prepAgo: 1, shelfHours: 5, pickupHours: 3 },
      { donor: 'Sunrise Bakery', title: 'Bread loaves and buns', category: 'Bakery', servings: 25, kg: 6, location: 'Benz Circle, Vijayawada', contact: '98480 22222', prepAgo: 6, shelfHours: 24, pickupHours: 8 },
      { donor: 'Lakshmi Family', title: 'Rice, dal and curry from a function', category: 'Cooked meal', servings: 18, kg: 7, location: 'Patamata, Vijayawada', contact: '98480 33333', prepAgo: 2, shelfHours: 4, pickupHours: 2 }
    ].map((s, i) => ({
      id: 'seed' + i, donor: s.donor, title: s.title, category: s.category, servings: s.servings, kg: s.kg,
      location: s.location, contact: s.contact, notes: '', preparedAt: now - s.prepAgo * H,
      shelfHours: s.shelfHours, expiresAt: now - s.prepAgo * H + s.shelfHours * H, pickupBy: now + s.pickupHours * H,
      status: 'available', createdAt: now
    }));
    fs.writeFileSync(DB, JSON.stringify(seed, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB, 'utf8'));
}
const save = d => fs.writeFileSync(DB, JSON.stringify(d, null, 2));

// A listing that nobody collected in time is marked expired so it is never claimed.
function refresh(list) {
  const now = Date.now();
  list.forEach(l => { if (l.status === 'available' && now > Math.min(l.expiresAt, l.pickupBy)) l.status = 'expired'; });
  return list;
}

function stats(list) {
  const done = list.filter(l => l.status === 'collected');
  return {
    mealsSaved: done.reduce((a, l) => a + l.servings, 0),
    kgSaved: +done.reduce((a, l) => a + l.kg, 0).toFixed(1),
    collected: done.length,
    available: list.filter(l => l.status === 'available').length,
    claimed: list.filter(l => l.status === 'claimed').length,
    expired: list.filter(l => l.status === 'expired').length
  };
}

const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise(r => { let b = ''; req.on('data', c => (b += c)); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const clean = (v, n = 200) => String(v || '').trim().slice(0, n);
const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml' };

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;

  if (p.startsWith('/api/')) {
    const list = refresh(load());
    if (req.method === 'GET' && p === '/api/listings') { save(list); return send(res, 200, { listings: list.sort((a, b) => b.createdAt - a.createdAt), stats: stats(list) }); }

    if (req.method === 'POST' && p === '/api/listings') {
      const b = await body(req);
      const servings = parseInt(b.servings), kg = parseFloat(b.kg) || +(servings * 0.35).toFixed(1);
      const shelf = parseFloat(b.shelfHours), prepared = new Date(b.preparedAt).getTime() || Date.now();
      const pickupBy = new Date(b.pickupBy).getTime();
      if (!clean(b.donor) || !clean(b.title) || !clean(b.location) || !servings || !shelf || !pickupBy)
        return send(res, 400, { error: 'Fill in donor, food, servings, shelf life, location and pickup deadline.' });
      const item = {
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        donor: clean(b.donor), title: clean(b.title), category: clean(b.category, 30) || 'Cooked meal',
        servings, kg, location: clean(b.location), contact: clean(b.contact, 40), notes: clean(b.notes, 300),
        preparedAt: prepared, shelfHours: shelf, expiresAt: prepared + shelf * H, pickupBy,
        status: 'available', createdAt: Date.now()
      };
      list.push(item); save(list); return send(res, 201, item);
    }

    const m = p.match(/^\/api\/listings\/([\w-]+)\/(claim|collect|cancel)$/);
    if (req.method === 'POST' && m) {
      const item = list.find(l => l.id === m[1]);
      if (!item) return send(res, 404, { error: 'Listing not found.' });
      const b = await body(req);
      if (m[2] === 'claim') {
        if (item.status !== 'available') return send(res, 409, { error: 'This food is no longer available.' });
        if (!clean(b.name)) return send(res, 400, { error: 'Enter your name.' });
        item.status = 'claimed'; item.claimedBy = clean(b.name); item.claimOrg = clean(b.org); item.claimPhone = clean(b.phone, 40);
        item.pickupTime = new Date(b.pickupTime).getTime() || Date.now() + H;
      } else if (m[2] === 'collect') {
        if (item.status !== 'claimed') return send(res, 409, { error: 'Only claimed food can be marked collected.' });
        item.status = 'collected'; item.collectedAt = Date.now();
      } else {
        if (item.status === 'collected') return send(res, 409, { error: 'Already collected.' });
        item.status = 'cancelled';
      }
      save(list); return send(res, 200, item);
    }
    return send(res, 404, { error: 'Not found' });
  }

  const file = path.join(PUB, p === '/' ? 'index.html' : p);
  if (!file.startsWith(PUB) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}).listen(PORT, () => console.log(`Leftover Food Sharing App running at http://localhost:${PORT}`));
