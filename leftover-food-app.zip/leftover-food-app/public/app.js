const $ = s => document.querySelector(s);
const H = 3600 * 1000;
let state = { listings: [], stats: {} };
let role = localStorage.getItem('ps_role') || 'donor';
let me = JSON.parse(localStorage.getItem('ps_me') || '{"donor":"","name":"","org":"","phone":""}');
let claimId = null;

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = t => new Date(t).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const localInput = t => { const d = new Date(t - new Date().getTimezoneOffset() * 60000); return d.toISOString().slice(0, 16); };
const left = ms => { if (ms <= 0) return 'expired'; const m = Math.round(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m left` : `${m}m left`; };

function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2600); }
async function api(url, method = 'GET', data) {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: data ? JSON.stringify(data) : undefined });
  const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Something went wrong'); return j;
}
async function refresh() { state = await api('/api/listings'); render(); }

// Freshness: share of safe time left, from prepared time to expiry.
function freshness(l) {
  const now = Date.now(), total = l.expiresAt - l.preparedAt, rem = l.expiresAt - now, pct = Math.max(0, Math.min(100, (rem / total) * 100));
  if (rem <= 0) return { cls: 'bad', label: 'Expired', pct: 0, rem };
  if (pct < 35 || rem < 1.5 * H) return { cls: 'soon', label: 'Use soon', pct, rem };
  return { cls: 'fresh', label: 'Fresh', pct, rem };
}

function card(l) {
  const f = freshness(l);
  const cls = l.status === 'collected' ? 'done' : l.status === 'expired' ? 'expired' : l.status === 'cancelled' ? 'cancelled' : f.cls;
  const badge = { available: f.label, claimed: 'Claimed', collected: 'Collected', expired: 'Expired', cancelled: 'Cancelled' }[l.status];
  let actions = '';
  if (role === 'taker' && l.status === 'available') actions = `<button data-claim="${l.id}">Claim this food</button>`;
  if (role === 'taker' && l.status === 'claimed' && l.claimedBy === me.name) actions = `<button data-collect="${l.id}">Mark as collected</button><button class="ghost" data-cancel="${l.id}">Release</button>`;
  if (role === 'donor' && l.donor === me.donor && l.status === 'available') actions = `<button class="ghost" data-cancel="${l.id}">Withdraw listing</button>`;
  if (role === 'donor' && l.donor === me.donor && l.status === 'claimed') actions = `<button data-collect="${l.id}">Handed over</button>`;
  const claim = l.claimedBy ? `<p class="note">Claimed by <b>${esc(l.claimedBy)}</b>${l.claimOrg ? ' (' + esc(l.claimOrg) + ')' : ''}, pickup ${fmt(l.pickupTime)}${l.claimPhone ? ', ' + esc(l.claimPhone) : ''}</p>` : '';
  return `<article class="item ${cls}">
    <div class="head"><div><h3>${esc(l.title)}</h3><div class="by">${esc(l.donor)} · ${esc(l.category)}</div></div><span class="badge">${badge}</span></div>
    ${l.status === 'available' ? `<div class="meter" title="Freshness"><i style="width:${f.pct}%"></i></div><div class="facts"><span><b>${left(f.rem)}</b> before it is unsafe</span></div>` : ''}
    <div class="facts" style="margin-top:6px"><span><b>${l.servings}</b> servings (~${l.kg} kg)</span><span>Pickup by <b>${fmt(l.pickupBy)}</b></span><span>${esc(l.location)}</span>${l.contact ? `<span>${esc(l.contact)}</span>` : ''}</div>
    <div class="facts"><span>Prepared ${fmt(l.preparedAt)}</span><span>Safe for ${l.shelfHours}h</span></div>
    ${l.notes ? `<p class="note">${esc(l.notes)}</p>` : ''}${claim}
    ${actions ? `<div class="actions">${actions}</div>` : ''}</article>`;
}

function renderStats() {
  const s = state.stats;
  $('#stats').innerHTML = [[s.mealsSaved, 'meals saved'], [s.kgSaved, 'kg of food rescued'], [s.available, 'available now'], [s.claimed, 'waiting for pickup'], [s.expired, 'expired unused']]
    .map(([n, t]) => `<div class="stat"><b>${n ?? 0}</b><span>${t}</span></div>`).join('');
}

function renderSide() {
  const side = $('#side');
  if (role === 'donor') {
    const now = Date.now();
    side.innerHTML = `<form id="postForm"><h2>Share surplus food</h2>
      <label>Your name or restaurant<input name="donor" required value="${esc(me.donor)}"></label>
      <label>What food is it?<input name="title" required placeholder="e.g. Veg fried rice"></label>
      <div class="two"><label>Type<select name="category"><option>Cooked meal</option><option>Bakery</option><option>Fruits and vegetables</option><option>Packaged</option><option>Other</option></select></label>
      <label>Servings<input name="servings" type="number" min="1" required></label></div>
      <div class="two"><label>Weight in kg (optional)<input name="kg" type="number" step="0.1" min="0"></label>
      <label>Safe for (hours)<input name="shelfHours" type="number" step="0.5" min="0.5" required value="4"></label></div>
      <label>Prepared at<input name="preparedAt" type="datetime-local" required value="${localInput(now)}"></label>
      <label>Pickup deadline<input name="pickupBy" type="datetime-local" required value="${localInput(now + 3 * H)}"></label>
      <label>Pickup address<input name="location" required></label>
      <label>Contact phone<input name="contact"></label>
      <label>Notes (veg, allergens, containers)<textarea name="notes" rows="2"></textarea></label>
      <button class="primary">Post food</button></form>`;
    $('#postForm').onsubmit = async e => {
      e.preventDefault();
      const d = Object.fromEntries(new FormData(e.target));
      try { await api('/api/listings', 'POST', d); me.donor = d.donor; saveMe(); toast('Posted. Volunteers can see it now.'); await refresh(); }
      catch (er) { toast(er.message); }
    };
  } else {
    side.innerHTML = `<div class="panel"><h2>How to collect</h2><p>Pick food that is still fresh, claim it with a pickup time, then mark it collected when you have it. Items past their safe time are locked automatically.</p></div>`;
  }
}

function render() {
  $('#roleDonor').classList.toggle('on', role === 'donor');
  $('#roleTaker').classList.toggle('on', role === 'taker');
  renderStats(); renderSide();
  renderList();
}
function renderList() {
  const q = $('#q').value.toLowerCase(), cat = $('#cat').value;
  let items = state.listings.filter(l => (!cat || l.category === cat) && (!q || (l.title + l.location + l.donor).toLowerCase().includes(q)));
  if (role === 'donor') { $('#listTitle').textContent = 'Your listings'; items = items.filter(l => l.donor === me.donor && me.donor); }
  else { $('#listTitle').textContent = 'Food near you'; items = items.filter(l => l.status === 'available' || (l.status === 'claimed' && l.claimedBy === me.name)); }
  items.sort((a, b) => (a.status === 'available' ? a.expiresAt : Infinity) - (b.status === 'available' ? b.expiresAt : Infinity));
  $('#list').innerHTML = items.length ? items.map(card).join('') : `<div class="empty">${role === 'donor' ? 'You have not posted any food yet. Fill in the form to share surplus.' : 'No food available right now. Check back soon.'}</div>`;
}

const saveMe = () => localStorage.setItem('ps_me', JSON.stringify(me));
function setRole(r) { role = r; localStorage.setItem('ps_role', r); render(); }
$('#roleDonor').onclick = () => setRole('donor');
$('#roleTaker').onclick = () => setRole('taker');
$('#q').oninput = $('#cat').onchange = renderList;

$('#list').onclick = async e => {
  const b = e.target.closest('button'); if (!b) return;
  try {
    if (b.dataset.claim) {
      claimId = b.dataset.claim; const l = state.listings.find(x => x.id === claimId), f = $('#claimForm');
      $('#claimInfo').textContent = `${l.title} from ${l.donor}, pickup by ${fmt(l.pickupBy)}`;
      f.name.value = me.name; f.org.value = me.org; f.phone.value = me.phone;
      f.pickupTime.value = localInput(Math.min(Date.now() + H, l.pickupBy)); f.pickupTime.max = localInput(l.pickupBy);
      $('#claimErr').textContent = ''; $('#claimDlg').showModal();
    } else if (b.dataset.collect) { await api(`/api/listings/${b.dataset.collect}/collect`, 'POST'); toast('Marked as collected. Thank you!'); await refresh(); }
    else if (b.dataset.cancel) { await api(`/api/listings/${b.dataset.cancel}/cancel`, 'POST'); toast('Done'); await refresh(); }
  } catch (er) { toast(er.message); refresh(); }
};

$('#claimForm').onsubmit = async e => {
  if (e.submitter && e.submitter.value === 'cancel') return;
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  try { await api(`/api/listings/${claimId}/claim`, 'POST', d); me = { ...me, name: d.name, org: d.org, phone: d.phone }; saveMe(); $('#claimDlg').close(); toast('Claimed. Pick it up on time!'); await refresh(); }
  catch (er) { $('#claimErr').textContent = er.message; refresh(); }
};

refresh(); setInterval(refresh, 30000); // keeps freshness timers and availability live
